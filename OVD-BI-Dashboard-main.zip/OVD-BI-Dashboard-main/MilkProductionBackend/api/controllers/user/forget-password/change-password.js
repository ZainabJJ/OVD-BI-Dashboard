const { generateEncryptedPassword, comparePrevPassword } = require('../../../util');
const bcrypt = require('bcrypt-nodejs');


module.exports = {


  friendlyName: 'Change password',


  description: '',


  inputs: {
    email: {
      type: 'string',
      required: true
    },
    password: {
      type: 'string',
      required: true
    },
    token: {
      type: 'string',
      required: true
    }
  },


  exits: {
    invalid: {
      responseType: 'badRequest',
    },
  },


  fn: async function ({email, token, password}, exits) {
    sails.log.debug('calling user/forget-password/change-password');
    try{
      const user = await User.getOne({email, forgetPasswordToken: token});
      if(!user) {
        throw new Error('Invalid OTP');
      }

      if(user.password){

        const samePassword = await comparePrevPassword(password, user.password);
        if (samePassword) {
          sails.log.debug('Password same as old one.');
          return exits.success({status: false, data: [], message: 'You have entered your old password.'});
        }
      }




      const hashedPassword = await generateEncryptedPassword(password);
      await User.update({email, id: user.id}).set({ forgetPasswordToken: '', password: hashedPassword});

      sails.log.debug('Password changed.');
      return exits.success({status: true, data: [], message: 'Successfully changed password. Try login with new password.'});
    }catch(e){
      sails.log.error('error user/forget-password/change-password', e);
      return exits.invalid({status: false, data: [], message: e.message || 'server error'});
    }

  }


};