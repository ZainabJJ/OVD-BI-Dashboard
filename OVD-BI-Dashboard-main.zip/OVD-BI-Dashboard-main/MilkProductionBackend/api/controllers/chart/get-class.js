module.exports = {
  friendlyName: "Get class",

  description: "",

  inputs: {},

  exits: {
    invalid: {
      responseType: "badRequest",
    },
    serverError: {
      description: "send server",
      responseType: "serverError",
    },
    badRequest: {
      description: "Bad Request",
      responseType: "badRequest",
    },
  },

  fn: async function (inputs, exits) {
    try {
      var ClassesGroupQuery = `SELECT class FROM payroll GROUP BY class ORDER BY class ASC`;
      var rawResult = await sails.sendNativeQuery(ClassesGroupQuery);

      let classes = [];
      for (let index = 0; index < rawResult.rows.length; index++) {
        const element = rawResult.rows[index];
        classes.push(element.class);
      }
      return exits.success({
        status: true,
        data: classes,
        message: "Success",
      });
    } catch (error) {
      sails.log.error("Error calling chart/get-class ===>>> ", error);
      return exits.serverError({
        status: false,
        data: [],
        message: "Something went wrong",
      });
    }
  },
};
