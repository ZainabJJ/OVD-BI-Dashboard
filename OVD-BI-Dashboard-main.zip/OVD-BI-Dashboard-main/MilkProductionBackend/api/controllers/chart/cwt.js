const moment = require("moment");

module.exports = {
  friendlyName: "Cwt",

  description: "Cwt chart.",

  inputs: {
    startDate: {
      type: "string",
      required: true,
    },
    endDate: {
      type: "string",
      required: true,
    },
    class: {
      type: "ref",
    },
  },

  exits: {
    invalid: {
      responseType: "badRequest",
    },
    serverError: {
      description: "send server",
      responseType: "serverError",
    },
    badRequest: {
      description: "Bad Request",
      responseType: "badRequest",
    },
  },

  fn: async function (inputs, exits) {
    try {
      let dateFilter = {
        filter: {
          ">=": moment(inputs.startDate, "MM/DD/YYYY")
            .startOf("day")
            .toISOString(),
          "<=": moment(inputs.endDate, "MM/DD/YYYY").endOf("day").toISOString(),
        },
      };
      let response = [];
      let classes = [];
      let hundredWeightTotal = 0;
      let payrollTotal = 0;
      if (_.isNil(inputs.class) || _.isEmpty(inputs.class)) {
        var ClassesGroupQuery = `SELECT class FROM payroll GROUP BY class ORDER BY class ASC`;
        var rawResult = await sails.sendNativeQuery(ClassesGroupQuery);

        for (let index = 0; index < rawResult.rows.length; index++) {
          const element = rawResult.rows[index];
          classes.push(element.class);
        }
      } else {
        classes = inputs.class;
      }
      if (!_.isEmpty(classes)) {
        let barns = ["Barn 1", "Barn 4", "Barn 5"];
        let diff = _.difference(classes, barns);
        if (_.includes(classes, "Barn 1")) {
          let payrollDataBarn1 = await Payroll.sum("amount").where({
            class: "Barn 1",
            date: dateFilter.filter,
          });
          let ovdDataBarn1 = await Ovd.sum("net_weight").where({
            commodity: "Barn 1",
            time_out: dateFilter.filter,
          });
          let barn1HundredWeight = ovdDataBarn1 / global.DIVISION_VALUE;
          let calulateBarn1 = payrollDataBarn1 / barn1HundredWeight;
          response.push({
            name: "Barn 1",
            cwtCost: Math.abs(calulateBarn1),
            hundredWeight: Math.abs(barn1HundredWeight),
            payroll: Math.abs(payrollDataBarn1),
          });
          hundredWeightTotal = hundredWeightTotal + barn1HundredWeight;
          payrollTotal = payrollTotal + payrollDataBarn1;
        }
        if (_.includes(classes, "Barn 4")) {
          let payrollDataBarn4 = await Payroll.sum("amount").where({
            class: "Barn 4",
            date: dateFilter.filter,
          });
          let ovdDataBarn4 = await Ovd.sum("net_weight").where({
            commodity: "Barn 4",
            time_out: dateFilter.filter,
          });
          let barn4HundredWeight = ovdDataBarn4 / global.DIVISION_VALUE;
          let calulateBarn4 = payrollDataBarn4 / barn4HundredWeight;

          response.push({
            name: "Barn 4",
            cwtCost: Math.abs(calulateBarn4),
            hundredWeight: Math.abs(barn4HundredWeight),
            payroll: Math.abs(payrollDataBarn4),
          });
          hundredWeightTotal = hundredWeightTotal + barn4HundredWeight;
          payrollTotal = payrollTotal + payrollDataBarn4;
        }
        if (_.includes(classes, "Barn 5")) {
          let payrollDataBarn5 = await Payroll.sum("amount").where({
            class: "Barn 5",
            date: dateFilter.filter,
          });
          let ovdDataBarn5 = await Ovd.sum("net_weight").where({
            commodity: "Barn 5",
            time_out: dateFilter.filter,
          });

          let barn5HundredWeight = ovdDataBarn5 / global.DIVISION_VALUE;
          let calulateBarn5 = payrollDataBarn5 / barn5HundredWeight;
          response.push({
            name: "Barn 5",
            cwtCost: Math.abs(calulateBarn5),
            hundredWeight: Math.abs(barn5HundredWeight),
            payroll: Math.abs(payrollDataBarn5),
          });
          hundredWeightTotal = hundredWeightTotal + barn5HundredWeight;
          payrollTotal = payrollTotal + payrollDataBarn5;
        }

        if (diff.length > 0) {
          for (let index = 0; index < diff.length; index++) {
            const element = diff[index];
            let payrollDataClass = await Payroll.sum("amount").where({
              class: element,
              date: dateFilter.filter,
            });
            response.push({
              name: element,
              cwtCost: 0,
              payroll: Math.abs(payrollDataClass),
            });
          }
        }
        if (!_.isEmpty(response)) {
          let total = _.sumBy(response, "cwtCost");
          total = total / 3;
          response.push({
            name: "Total",
            cwtCost: Math.abs(total),
            hundredWeight: Math.abs(hundredWeightTotal),
            payroll: Math.abs(payrollTotal),
          });
        }
      }

      return exits.success({
        status: true,
        data: response,
        message: "Success",
      });
    } catch (error) {
      sails.log.error("Error calling chart/cwt ===>>> ", error);
      return exits.serverError({
        status: false,
        data: [],
        message: "Something went wrong",
      });
    }
  },
};
