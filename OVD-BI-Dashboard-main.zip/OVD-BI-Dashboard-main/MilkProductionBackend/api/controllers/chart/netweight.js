const moment = require("moment");
module.exports = {
  friendlyName: "Netweight",

  description: "Netweight chart.",

  inputs: {
    startDate: {
      type: "string",
      required: true,
    },
    endDate: {
      type: "string",
      required: true,
    },
    class: {
      type: "ref",
    },
  },

  exits: {
    invalid: {
      responseType: "badRequest",
    },
    serverError: {
      description: "send server",
      responseType: "serverError",
    },
    badRequest: {
      description: "Bad Request",
      responseType: "badRequest",
    },
  },

  fn: async function (inputs, exits) {
    // let dateFilter = {
    //   filter: {
    //     ">=": moment(inputs.startDate, "DD/MM/YYYY")
    //       .startOf("day")
    //       .toISOString(),
    //     "<=": moment(inputs.endDate, "DD/MM/YYYY").endOf("day").toISOString(),
    //   },
    // };

    const startDate = moment(inputs.startDate, "MM/DD/YYYY");
    const endDate = moment(inputs.endDate, "MM/DD/YYYY");
    const dates = [];
    let response = [];
    let now = startDate.clone();

    while (now.isSameOrBefore(endDate)) {
      dates.push(now.format("DD/MM/YYYY"));
      now.add(1, "days");
    }

    console.log(dates);
    let classes = [];
    if (_.isNil(inputs.class) || _.isEmpty(inputs.class)) {
      classes = ["Barn 1", "Barn 4", "Barn 5"];
    } else {
      classes = inputs.class;
    }
    if (!_.isEmpty(classes)) {
      for (let index = 0; index < dates.length; index++) {
        const element = dates[index];
        let obj = { name: moment(element, "DD/MM/YYYY").format("MM/DD/YYYY") };
        if (_.includes(classes, "Barn 1")) {
          let ovdDataBarn1 = await Ovd.sum("net_weight").where({
            commodity: "Barn 1",
            time_out: {
              ">=": moment(element, "DD/MM/YYYY").startOf("day").toISOString(),
              "<=": moment(element, "DD/MM/YYYY").endOf("day").toISOString(),
            },
          });
          obj.barn1 = ovdDataBarn1;
        }
        if (_.includes(classes, "Barn 4")) {
          let ovdDataBarn4 = await Ovd.sum("net_weight").where({
            commodity: "Barn 4",
            time_out: {
              ">=": moment(element, "DD/MM/YYYY").startOf("day").toISOString(),
              "<=": moment(element, "DD/MM/YYYY").endOf("day").toISOString(),
            },
          });
          obj.barn4 = ovdDataBarn4;
        }
        if (_.includes(classes, "Barn 5")) {
          let ovdDataBarn5 = await Ovd.sum("net_weight").where({
            commodity: "Barn 5",
            time_out: {
              ">=": moment(element, "DD/MM/YYYY").startOf("day").toISOString(),
              "<=": moment(element, "DD/MM/YYYY").endOf("day").toISOString(),
            },
          });
          obj.barn5 = ovdDataBarn5;
        }
        response.push(obj);
      }
    }
    return exits.success({
      status: true,
      data: response,
      message: "Success",
    });
  },
};
