const moment = require("moment");
const { extendMoment } = require("moment-range");

module.exports = {
  friendlyName: "Upload data",

  description: "",

  inputs: {
    data: {
      type: "ref",
      required: true,
    },
  },

  exits: {
    invalid: {
      responseType: "badRequest",
    },
    serverError: {
      description: "send server",
      responseType: "serverError",
    },
    badRequest: {
      description: "Bad Request",
      responseType: "badRequest",
    },
  },

  fn: async function (inputs, exits) {
    try {
      let milkProdHeader = [
        "Scale Ticket #",
        "Time In",
        "Time Out",
        "Commodity",
        "Broker",
        "Hauler",
        "Heavy Weight (lbs)",
        "Light Weight (lbs)",
        "Net Weight  (lbs) AsFed",
        "Bill Of Lading",
        "Truck",
        "Total",
        "cwt",
      ];
      let payrollHeader = ["Date", "Num", "Name", "Class", "Amount"];

      let milkProdHeaderCheck = _.isEqual(milkProdHeader, inputs.data[0]);
      let payrollHeaderCheck = _.isEqual(payrollHeader, inputs.data[0]);
      if (milkProdHeaderCheck || payrollHeaderCheck) {
        inputs.data.shift();
        let data = inputs.data;
        if (milkProdHeaderCheck) {
          for (let index = 0; index < data.length; index++) {
            const element = data[index];

            console.log(moment(element[2], "M/D/YYYY h:m A").utc().format());
            let check = await Ovd.find({
              scale_ticket: element[0],
              time_out: moment(element[2], "M/D/YYYY h:m A")
                .utc()
                .toISOString(),
            });
            let heavy_weight = parseInt(element[6].replace(/,/g, ""));
            if (_.isNaN(heavy_weight)) {
              heavy_weight = 0;
            }
            let light_weight = parseInt(element[7].replace(/,/g, ""));
            if (_.isNaN(light_weight)) {
              light_weight = 0;
            }
            let net_weight = parseInt(element[8].replace(/,/g, ""));
            if (_.isNaN(net_weight)) {
              net_weight = 0;
            }
            let bill_of_lading = parseInt(element[9].replace(/,/g, ""));
            if (_.isNaN(bill_of_lading)) {
              bill_of_lading = 0;
            }
            let total = parseInt(element[11].replace(/,/g, ""));
            if (_.isNaN(total)) {
              total = 0;
            }
            let cwt = parseInt(element[12].replace(/,/g, ""));
            if (_.isNaN(cwt)) {
              cwt = 0;
            }
            if (check.length == 0) {
              await Ovd.create({
                scale_ticket: element[0],
                time_in: moment(element[1], "M/D/YYYY h:m A")
                  .utc()
                  .toISOString(),
                time_out: moment(element[2], "M/D/YYYY h:m A")
                  .utc()
                  .toISOString(),
                commodity: element[3],
                broker: element[4],
                hauler: element[5],
                heavy_weight: heavy_weight,
                light_weight: light_weight,
                net_weight: net_weight,
                bill_of_lading: bill_of_lading,
                truck: element[10],
                total: total,
                cwt: cwt,
                updatedAt: moment().utc().toISOString(),
                createdAt: moment().utc().toISOString(),
              });
            } else {
              await Ovd.update({
                scale_ticket: element[0],
                time_out: moment(element[2], "M/D/YYYY h:m A")
                  .utc()
                  .toISOString(),
              }).set({
                scale_ticket: element[0],
                time_in: moment(element[1], "M/D/YYYY h:m A")
                  .utc()
                  .toISOString(),
                time_out: moment(element[2], "M/D/YYYY h:m A")
                  .utc()
                  .toISOString(),
                commodity: element[3],
                broker: element[4],
                hauler: element[5],
                heavy_weight: heavy_weight,
                light_weight: light_weight,
                net_weight: net_weight,
                bill_of_lading: bill_of_lading,
                truck: element[10],
                total: total,
                cwt: cwt,
                updatedAt: moment().utc().toISOString(),
              });
            }
          }
        } else {
          for (let index = 0; index < data.length; index++) {
            let element = data[index];

            // let check = await Payroll.find({
            //   num: element[1],
            //   date: moment(element[0], "dd/mm/yyyy").utc().toISOString(),
            // });
            // if (check.length == 0) {

            let num = parseInt(element[1].replace(/,/g, ""));
            let amount = parseInt(element[4].replace(/,/g, ""));
            if (_.isNaN(num)) {
              num = 0;
            }
            if (_.isNaN(amount)) {
              amount = 0;
            }
            console.log(
              moment(element[0], "MM/DD/YYYY").utc().format("YYYY-MM-DD")
            );
            await Payroll.create({
              date: moment(element[0], "MM/DD/YYYY")
                .subtract(6, "days")
                .utc()
                .format("YYYY-MM-DD"),
              num: num,
              name: element[2],
              class: element[3],
              amount: amount,
              updatedAt: moment().utc().toISOString(),
              createdAt: moment().utc().toISOString(),
            });
            // } else {
            //   await Payroll.update({
            //     num: element[1],
            //     date: moment(element[0], "dd/mm/yyyy").utc().toISOString(),
            //   }).set({
            //     date: moment(element[0], "M/D/YYYY h:m A")
            //       .utc()
            //       .toISOString(),
            //     num: parseInt(element[1].replace(/,/g, "")),
            //     name: element[2],
            //     class: element[3],
            //     amount: parseInt(element[4].replace(/,/g, "")),
            //     updatedAt: moment().utc().toISOString(),
            //   });
            // }
          }
        }
        sails.log.debug("data imported");
        return exits.success({
          status: true,
          data: [],
          message: "Data imported successfully",
        });
      }
      sails.log.error("headers do not match");
      return exits.invalid({
        status: false,
        data: [],
        message: "Invalid File: Headers do not match",
      });
    } catch (error) {
      sails.log.error("Error calling upload-data ===>>> ", error);
      return exits.serverError({
        status: false,
        data: [],
        message: "Something went wrong",
      });
    }
  },
};
