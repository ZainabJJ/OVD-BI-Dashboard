module.exports = {


  friendlyName: 'Confirm otp',


  description: '',


  inputs: {
    image: {
      type: 'string',
      required: true
    },
    email: {
      type: 'string',
      required: true,
      isEmail: true,
    },
    name: {
      type: 'string',
      required: true
    },
    password: {
      type: 'string',
      required: true
    },
    otp: {
      type: 'string',
      required: true
    }
  },


  exits: {
    invalid: {
      responseType: 'badRequest',
      description: 'Driver not exists',
    },
  },


  fn: async function (inputs, exits) {
    const {email, otp} = inputs;
    sails.log.debug('calling confirm-otp', {email, otp});
    try{
      const req = this.req;
      const res = this.res;
      const data = await sails.models.userrequest.findOne({email, otp});
      sails.log.debug('data', data);
      if (!data) {
        throw new Error('Invalid OTP');
      }

      const obj = {
        image: inputs.image,
        email: inputs.email,
        name: inputs.name,
        password: inputs.password
      }
      const isValidated = await sails.helpers.user.validate.with(obj);
      if(!isValidated) {
        throw new Error('Invalid payload.');
      }

      await sails.models.user.create(inputs);
      await sails.models.userrequest.destroy({email, otp});
      const user = await sails.models.user.getOne({email});
      req.login(user, (err) => {
        if (err) {return res.badRequest(err);}
        sails.log('User ' + user.id + ' has logged in');
        return res.send({
          status: true,
          message: 'Logged in successfully',
          data: user,
        });
      });
    }catch(e){
      sails.log.error('error registration', e);
      // const _msg = typeof e !== 'string'? 'Unknown Error' : e;
      return exits.invalid({status: false, data: [], message: e.message});

    }
    // All done.
    return;

  }


};
