CREATE table user_request(
    id serial primary key,
    "email" varchar(255),
    "otp" varchar(255),
    "createdAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP
);