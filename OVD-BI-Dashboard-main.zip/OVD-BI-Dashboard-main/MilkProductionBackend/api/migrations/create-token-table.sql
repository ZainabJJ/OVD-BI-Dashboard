CREATE table token(
    id serial primary key,
    "token" text,
    "user_id" int,
    "createdAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP
);