CREATE TABLE "ovd" (
    id serial primary key,
    "scale_ticket" varchar(255),
    "time_in" timestamp DEFAULT NULL,
    "time_out" timestamp DEFAULT NULL,
    "commodity" text,
    "broker" text,
    "hauler" text,
    "heavy_weight" bigint,
    "light_weight" bigint,
    "net_weight" bigint,
    "bill_of_lading" bigint,
    "truck" text,
    "total" bigint,
    "cwt" bigint,
    "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP
);