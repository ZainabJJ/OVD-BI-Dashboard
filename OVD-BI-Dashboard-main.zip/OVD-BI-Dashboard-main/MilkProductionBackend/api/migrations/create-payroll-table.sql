CREATE TABLE "payroll" (
    id serial primary key,
    "date" DATE DEFAULT NULL,
    "num" bigint,
    "name" text,
    "class" text,
    "amount" bigint,
    "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP
);