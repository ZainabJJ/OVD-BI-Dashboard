CREATE table "user"(
    id serial primary key,
    "email" varchar(255),
    "name" varchar(255),
    "password" varchar(255),
    "image" text,
    "phone" varchar(255),
    "otp" varchar(255),
    "forgetPasswordToken" text,
    "deletedAt" timestamp with time zone  DEFAULT NULL,
    "createdAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone  DEFAULT CURRENT_TIMESTAMP
);