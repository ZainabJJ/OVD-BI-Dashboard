/**
 * Ovd.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    scale_ticket: {
      type: "string",
      required: false,
    },
    time_in: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
    time_out: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
    commodity: {
      type: "string",
      required: false,
    },
    broker: {
      type: "string",
      required: false,
    },
    hauler: {
      type: "string",
      required: false,
    },
    heavy_weight: {
      type: "number",
      required: false,
    },
    light_weight: {
      type: "number",
      required: false,
    },
    net_weight: {
      type: "number",
      required: false,
    },
    bill_of_lading: {
      type: "number",
      required: false,
    },
    truck: {
      type: "string",
      required: false,
    },
    total: {
      type: "number",
      required: false,
    },
    cwt: {
      type: "number",
      required: false,
    },
    updatedAt: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
    createdAt: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
  },
};
