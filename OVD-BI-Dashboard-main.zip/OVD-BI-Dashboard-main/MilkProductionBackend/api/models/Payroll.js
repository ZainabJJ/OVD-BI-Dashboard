/**
 * Payroll.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    num: {
      type: "number",
      required: false,
    },
    amount: {
      type: "number",
      required: false,
    },
    class: {
      type: "string",
      required: false,
    },
    name: {
      type: "string",
      required: false,
    },
    date: {
      type: "ref",
      columnType: "date",
      required: false,
    },
    updatedAt: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
    createdAt: {
      type: "ref",
      columnType: "datetime",
      required: false,
    },
  },
};
