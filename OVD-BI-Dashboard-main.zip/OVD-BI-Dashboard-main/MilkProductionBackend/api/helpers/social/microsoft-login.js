const axios = require("axios");
module.exports = {
  friendlyName: "Microsoft login",

  description: "",

  inputs: {
    token: {
      type: "string",
      required: true,
    },
  },

  exits: {
    success: {
      description: "All done.",
    },
  },

  fn: async function (inputs, exits) {
    sails.log("calling helper social/microsoft-login");

    try {
      let getInfoUrl = "https://graph.microsoft.com/oidc/userinfo";
      const AuthStr = "Bearer ".concat(inputs.token);
      let response = await axios.get(getInfoUrl, {
        headers: { Authorization: AuthStr },
      });

      let getEmailUrl = "https://graph.microsoft.com/v1.0/me";
      let emailResponse = await axios.get(getEmailUrl, {
        headers: { Authorization: AuthStr },
      });

      response.data.email = emailResponse.data.userPrincipalName;

      return exits.success(response.data);
    } catch (error) {
      sails.log.error("error in helpers/social/fb-login:  ====>", error);
      return exits.success();
    }
  },
};
