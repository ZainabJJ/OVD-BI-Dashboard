module.exports = function (req, res, next) {
  "user strict";
    sails.log.debug('req.headers',req.headers);
  if ( !_.isUndefined(req.headers['is_admin']) ){
    return next();
  }
  else {
    res.forbidden({ status: false, message: "Unauhorized", data: [] });
  }
};
