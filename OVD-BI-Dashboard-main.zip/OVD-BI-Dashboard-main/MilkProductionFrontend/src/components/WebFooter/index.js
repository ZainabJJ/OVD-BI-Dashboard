import WebFooterController from "./WebFooterController";

export default WebFooterController;
