// @flow
import React from "react";
import { css } from "aphrodite";
import styles from "./WebFooterStyles";

export default function WebFooterView(props) {
  return <div>footer</div>;
}
