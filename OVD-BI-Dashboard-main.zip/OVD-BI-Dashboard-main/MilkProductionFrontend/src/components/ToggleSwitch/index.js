import ToggleSwitchController from "./ToggleSwitchController";

export default ToggleSwitchController;