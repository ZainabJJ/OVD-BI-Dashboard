import SignupController from './SignupController';

export default SignupController;
