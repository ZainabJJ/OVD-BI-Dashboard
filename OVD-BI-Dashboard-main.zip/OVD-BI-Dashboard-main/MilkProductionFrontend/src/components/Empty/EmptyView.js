// @flow
import React from "react";
import { css } from "aphrodite";
import styles from "./EmptyStyles";

export default function EmptyView(props) {
  return <div>welcome</div>;
}
