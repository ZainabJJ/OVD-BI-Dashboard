import EmptyController from "./EmptyController";

export default EmptyController;
