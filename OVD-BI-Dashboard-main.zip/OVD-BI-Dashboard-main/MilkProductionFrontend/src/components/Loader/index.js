import LoaderController from "./LoaderController";

export default LoaderController;
