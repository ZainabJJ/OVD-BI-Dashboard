// @flow
import { StyleSheet } from "aphrodite";

export default StyleSheet.create({
  loaderWrap: {
    textAlign: "center",
  }
});
