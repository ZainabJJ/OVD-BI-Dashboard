import React, { PureComponent } from "react";
import { PieChart, Pie, Sector, Cell, ResponsiveContainer } from "recharts";

const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({
	cx,
	cy,
	midAngle,
	innerRadius,
	outerRadius,
	percent,
	index,
}) => {
	const radius = innerRadius + (outerRadius - innerRadius) * 0.2;
	const x = cx + radius * Math.cos(-midAngle * RADIAN);
	const y = cy + radius * Math.sin(-midAngle * RADIAN);

	return (
		<text
			style={{ fontSize: 10 }}
			fill="#000"
			dominantBaseline="central"
			x={cx}
			y={cy}
			dy={1}
			textAnchor="middle"
			// fill={fill}
		>
			{`${(percent * 100).toFixed(0)}%`}
		</text>
	);
};

export default class SmallPieChart extends PureComponent {
	render() {
		const { dataChart, COLORS } = this.props;
		return (
			<PieChart width={60} height={60}>
				<Pie
					data={dataChart}
					cx="50%"
					cy="50%"
					labelLine={false}
					label={renderCustomizedLabel}
					outerRadius={30}
					innerRadius={25}
					fill="#8884d8"
					dataKey="value"
				>
					{dataChart.map((entry, index) => (
						<Cell
							key={`cell-${index}`}
							fill={COLORS[index % COLORS.length]}
						/>
					))}
				</Pie>
			</PieChart>
		);
	}
}
