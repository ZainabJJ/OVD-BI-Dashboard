import HeaderController from "./HeaderController";

export default HeaderController;
