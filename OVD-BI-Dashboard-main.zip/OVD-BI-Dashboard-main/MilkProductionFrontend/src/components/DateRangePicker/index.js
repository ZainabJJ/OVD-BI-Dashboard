import * as React from "react";
import TextField from "@mui/material/TextField";
import DateRangePicker from "@mui/lab/DateRangePicker";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import Box from "@mui/material/Box";
import _ from "lodash";
export default function BasicDateRangePicker(props) {
	const { onChange, value } = props;

	return (
		<LocalizationProvider dateAdapter={AdapterDateFns}>
			<DateRangePicker
				startText="Start Date"
				endText="End Date"
				value={value}
				inputFormat={"MM-dd-yyyy"}
				onChange={(newValue) => {
					if (!_.isNull(newValue[1])) {
						onChange(newValue);
					}
				}}
				renderInput={(startProps, endProps) => (
					<React.Fragment>
						<TextField {...startProps} />
						<Box sx={{ mx: 2 }}> to </Box>
						<TextField {...endProps} />
					</React.Fragment>
				)}
			/>
		</LocalizationProvider>
	);
}
