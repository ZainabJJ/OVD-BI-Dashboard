import LoginController from './LoginController';

export default LoginController;
