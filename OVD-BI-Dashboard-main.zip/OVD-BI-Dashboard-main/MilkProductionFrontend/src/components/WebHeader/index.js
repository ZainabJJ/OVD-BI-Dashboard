import WebHeaderController from "./WebHeaderController";

export default WebHeaderController;
