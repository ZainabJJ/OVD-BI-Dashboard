// @flow
import React from "react";
import { css } from "aphrodite";
import styles from "./WebHeaderStyles";

export default function WebHeaderView(props) {
  return <div>Header</div>;
}
