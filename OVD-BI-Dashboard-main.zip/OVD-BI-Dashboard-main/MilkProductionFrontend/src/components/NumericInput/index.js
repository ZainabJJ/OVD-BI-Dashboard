import NumericInputController from './NumericInputController';

export default NumericInputController;
