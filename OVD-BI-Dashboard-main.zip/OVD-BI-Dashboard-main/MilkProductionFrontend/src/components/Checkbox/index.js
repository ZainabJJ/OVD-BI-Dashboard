import CheckboxController from "./CheckboxController";

export default CheckboxController;
