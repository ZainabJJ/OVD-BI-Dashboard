import ModalView from "./ModalView";

export default ModalView;
