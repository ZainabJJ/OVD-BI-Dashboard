import React, { PureComponent } from "react";
import {
	BarChart,
	Bar,
	Cell,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	Legend,
	ResponsiveContainer,
} from "recharts";

const data = [];

export default class StackedBarChart extends PureComponent {
	render() {
		const { data } = this.props;
		return (
			<BarChart
				width={window.innerWidth - 400}
				height={300}
				data={data}
				margin={{
					top: 20,
					right: 30,
					left: 20,
					bottom: 5,
				}}
			>
				<CartesianGrid strokeDasharray="3 3" />
				<XAxis dataKey="name" />
				<YAxis />
				<Tooltip />
				<Legend />
				<Bar dataKey="barn1" stackId="a" fill="#8884d8" />
				<Bar dataKey="barn4" stackId="a" fill="#82ca9d" />
				<Bar dataKey="barn5" stackId="a" fill="#81a59d" />
			</BarChart>
		);
	}
}
