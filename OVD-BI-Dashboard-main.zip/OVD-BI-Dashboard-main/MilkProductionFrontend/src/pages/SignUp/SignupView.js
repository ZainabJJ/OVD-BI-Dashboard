// @flow
import React from 'react';
import { css } from 'aphrodite';
import { Images, AppStyles } from '../../theme';
import { TextField, Button } from '../../components';
import { NavLink } from 'react-router-dom';
import { USER_LOGIN_THEME, ROUTES } from '../../constants';
import styles from './SignupViewStyles';
import {
  CardElement,
  Elements,
  ElementsConsumer
} from '@stripe/react-stripe-js';

export default function SignupViewView(props) {
  const { step, nextClick, previousClick, data } = props;
  return (
    <div className={`${css(styles.wrapper,)}`} >
      <div className={`${css(styles.signinBgColor, AppStyles.container)}`}>
        <div className={`${css(styles.signinWraper)}`}>
          <div className={`row`}>
            <div className={`col-lg-3 col-md-3 col-sm-12`}>
              <div className={css(styles.signinHeadContainer)}>
                <h6 className={css(styles.signinHead)}>Sign up</h6>
                <h4 className={css(styles.signinSubHead)}>Get started !</h4>
              </div>
            </div>

            <div className={`col-lg-12 col-md-12 col-sm-12`}>
              <form className={css(styles.formContainer)}>
                {/* Step 1 personalInfo*/}

                {step === 0 && (
                  <div className={`row mb-2 ${css(styles.personalInfo)}`}>
                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        First name
                      </label>
                      <input
                        type="text"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="firstName"
                        value={props.firstName}
                        onChange={props.onInputChange}
                        placeholder="John"
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.firstNameError}
                      </span>
                    </div>
                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        Last name
                      </label>

                      <input
                        type="text"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="lastName"
                        value={props.lastName}
                        onChange={props.onInputChange}
                        placeholder="Smith"
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.lastNameError}
                      </span>
                    </div>

                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        Work email
                      </label>

                      <input
                        type="email"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="email"
                        value={props.email}
                        onChange={props.onInputChange}
                        placeholder="abc@123.com"
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.emailError}
                      </span>
                    </div>

                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        Phone number
                      </label>

                      <input
                        type="tel"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="phone"
                        value={props.phone}
                        onChange={props.onInputChange}
                        placeholder="07210310110"
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.phoneError}
                      </span>
                    </div>

                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        Password
                      </label>

                      <input
                        type="password"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="password"
                        value={props.password}
                        onChange={props.onInputChange}
                        placeholder="******"
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.passwordError}
                      </span>
                    </div>

                    <div className={`form-group col-md-4`}>
                      <label className={`mb-2 ${css(styles.labelForm)}`}>
                        Confirm Password
                      </label>

                      <input
                        type="password"
                        className={`form-control ${css(styles.inputControl)}`}
                        name="confirmPassword"
                        value={props.confirmPassword}
                        onChange={props.onInputChange}
                        placeholder="******"
                        onKeyDown={e => {
                          if (e.key === 'Enter') nextClick();
                        }}
                      ></input>
                      <span className={`${css(AppStyles.formError)}`}>
                        {props.confirmPasswordError}
                      </span>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>

          <div className={`row`}>
            <div className={`col-lg-4 col-md-4 col-sm-12 `}></div>
            <div
              className={`col-md-offset-4 col-lg-offset-4 col-lg-8 col-md-8 col-sm-12 `}
            >
              <div>
                <div className={css(styles.signinBtnContainer)}>
                  <NavLink className={css(styles.signinText)} to={ROUTES.LOGIN}>
                    Already have an account ?
                  </NavLink>
                  <Button
                    title="Next"
                    isLoading={props.isLoading}
                    className={css(styles.nextBtn)}
                    onClick={() => nextClick()}
                    ripple={false}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
