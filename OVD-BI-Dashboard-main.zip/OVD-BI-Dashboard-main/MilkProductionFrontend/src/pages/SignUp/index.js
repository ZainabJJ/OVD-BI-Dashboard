import SignupViewController from './SignupViewController';

export default SignupViewController;
