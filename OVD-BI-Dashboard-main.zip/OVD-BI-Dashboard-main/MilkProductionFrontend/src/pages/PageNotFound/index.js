import PageNotFoundController from "./PageNotFoundController";

export default PageNotFoundController;
