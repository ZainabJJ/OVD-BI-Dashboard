import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import { Drawer } from "../../components";
import * as moment from "moment";
import _ from "lodash";
import {
	PieChart,
	MultipleSelect,
	BarChart,
	DateRangePicker,
} from "../../components";
import { Grid, Typography } from "@mui/material/index";
import { useDispatch, connect } from "react-redux";
import {
	barChartRequest,
	classListRequest,
	hundredsPayrollRequest,
} from "../../actions/BarnsAction";
import "./style.scss";
import Util from "../../services/Util";
import { ClipLoader } from "react-spinners";
import Box from "@mui/material/Box";

const drawerWidth = 240;
const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
	({ theme, open }) => ({
		flexGrow: 1,
		padding: theme.spacing(3),
		transition: theme.transitions.create("margin", {
			easing: theme.transitions.easing.sharp,
			duration: theme.transitions.duration.leavingScreen,
		}),
		marginLeft: `-${drawerWidth}px`,
		...(open && {
			transition: theme.transitions.create("margin", {
				easing: theme.transitions.easing.easeOut,
				duration: theme.transitions.duration.enteringScreen,
			}),
			marginLeft: 0,
		}),
	})
);

const DrawerHeader = styled("div")(({ theme }) => ({
	display: "flex",
	alignItems: "center",
	padding: theme.spacing(0, 1),
	// necessary for content to be below app bar
	...theme.mixins.toolbar,
	justifyContent: "flex-end",
}));

function Cart(props) {
	const {
		barnsClassList,
		barChart,
		barnsDetails,
		pieChartPayroll,
		pieChartHW,
		hundredWeight,
		payroll,
	} = props;
	const [startDate, setStartDate] = useState(new Date());
	const [selectDates, setSelectDates] = useState([null, null]);
	const [selectDatesError, setSelectDatesError] = useState("");
	const [item, setItem] = React.useState([]);
	const [classListError, setClassListError] = useState("");
	const [isLoading, setIsLoading] = useState(() => false);

	const dispatch = useDispatch();
	useEffect(() => {
		ApiCall();
		dispatch(classListRequest((res) => {}));
	}, []);

	const ApiCall = () => {
		setIsLoading(true);
		setTimeout(() => {
			let daterange = _.compact(selectDates);
			dispatch(
				hundredsPayrollRequest(
					{
						startDate: _.isEmpty(daterange)
							? moment().startOf("day").format("MM/DD/YYYY")
							: moment(daterange[0]).format("MM/DD/YYYY"),
						endDate: _.isEmpty(daterange)
							? moment().endOf("day").format("MM/DD/YYYY")
							: moment(daterange[1]).format("MM/DD/YYYY"),
						class: item,
					},
					(res) => {}
				)
			);
			dispatch(
				barChartRequest(
					{
						startDate: _.isEmpty(daterange)
							? moment().startOf("day").format("MM/DD/YYYY")
							: moment(daterange[0]).format("MM/DD/YYYY"),
						endDate: _.isEmpty(daterange)
							? moment().endOf("day").format("MM/DD/YYYY")
							: moment(daterange[1]).format("MM/DD/YYYY"),
						class: item,
					},
					(res) => {}
				)
			);
			setIsLoading(false);
		}, 1000);
	};

	const validation = () => {
		let isError = false;
		if (!_.isNull(selectDates[0])) {
			setSelectDatesError("Please,Select Date range");
			isError = true;
		}
		if (!_.isNull(selectDates[1])) {
			setSelectDatesError("Please,Select Date range");
			isError = true;
		}
		return isError;
	};

	const handleChange = (event) => {
		const {
			target: { value },
		} = event;
		setItem(typeof value === "string" ? value.split(",") : value);

		ApiCall();
	};

	const handleDatesChange = (newValue) => {
		setSelectDates(newValue);
		if (!_.isNull(selectDates[0]) && !_.isNull(selectDates[1])) {
			ApiCall();
		}
	};

	return (
		<Box sx={{ display: "flex" }}>
			<Drawer title={"Charts"} />
			<Main open={true}>
				<DrawerHeader />

				{isLoading === true ? (
					<div className="LoaderDiv">
						<ClipLoader />
					</div>
				) : (
					<></>
				)}
				<div className="fillerBar">
					<Grid container justifyContent={"space-between"}>
						<Grid item>
							<MultipleSelect
								value={item}
								items={barnsClassList}
								label="Class"
								onChange={handleChange}
							/>
							<h1
								style={{
									fontSize: 12,
									alignSelf: "center",
									marginLeft: 10,
									color: "red",
								}}
							>
								{classListError}
							</h1>
						</Grid>
						<Grid item></Grid>
						<Grid item>
							<DateRangePicker
								value={selectDates}
								onChange={handleDatesChange}
							/>
						</Grid>
					</Grid>
				</div>

				<div className="barnDetails">
					<h1>Barns Details</h1>

					<Grid container spacing={2}>
						{!_.isEmpty(barnsDetails) ? (
							barnsDetails?.map((item) => {
								return (
									<Grid item xs={4}>
										<div className="barnDetailItem">
											<div className="barnDetailItemContent">
												<h3 className="barnDetailItemHeader">
													{item.h1}
												</h3>
												<h1 style={{ fontSize: "0.8em" }}>
													{item.h2}
												</h1>
											</div>
											<div className="barnDetailItemPie">
												<h3 className="barnDetailItemAmount">
													{item.h3}
												</h3>
											</div>
										</div>
									</Grid>
								);
							})
						) : (
							<></>
						)}
					</Grid>
				</div>
				{!_.isEmpty(hundredWeight) ? (
					<div className="HWMainContainer">
						<h1>Hundred weight </h1>
						<Grid container spacing={0}>
							{hundredWeight?.map((item) => {
								return (
									<Grid className="HWContentContainer" item xs={3}>
										<div className="HWContent">
											<div className="HWTitle">{item.title}</div>
											<div className="HWValue">
												{Util.intToString(item.value)}
											</div>
										</div>
									</Grid>
								);
							})}
						</Grid>
					</div>
				) : (
					<></>
				)}
				{!_.isEmpty(payroll) ? (
					<div className="HWMainContainer">
						<h1>Payroll </h1>
						<Grid container spacing={0}>
							{payroll?.map((item) => {
								return (
									<Grid className="HWContentContainer" item xs={3}>
										<div className="HWContent">
											<div className="HWTitle">{item.title}</div>
											<div className="HWValue">
												{Util.intToString(item.value)}
											</div>
										</div>
									</Grid>
								);
							})}
						</Grid>
					</div>
				) : (
					<></>
				)}

				<div className="PieChartContainer">
					<Grid container spacing={0}>
						<Grid className="PieChartKeys" item xs={6}>
							<h1>Milk Production</h1>
							<Grid container spacing={0}>
								<Grid className="PieChartDiag" item xs={8}>
									<PieChart
										dataChart={pieChartHW}
										COLORS={[
											"#F5B7B1",
											"#D7BDE2",
											"#AED6F1",
											"#A3E4D7",
											"#7DCEA0",
											"#F5CBA7",
											"#CCD1D1",
											"#F5B041",
										]}
									/>
								</Grid>
								<Grid className="PieChartKeys" item xs={4}>
									{pieChartHW.map((item) => {
										return (
											<div className="pieChartItemName">
												<div
													style={{
														width: 10,
														height: 10,
														background: item.color,
														borderRadius: 20,
													}}
												/>
												<h1
													style={{
														fontSize: "0.7em",
														marginLeft: 10,
														marginBottom: 0,
													}}
												>
													{item.name}
												</h1>
											</div>
										);
									})}
								</Grid>
							</Grid>
						</Grid>
						<Grid className="PieChartKeys" item xs={6}>
							<h1>Payroll Expenses</h1>
							<Grid container spacing={0}>
								<Grid className="PieChartDiag" item xs={8}>
									<PieChart
										dataChart={pieChartPayroll}
										COLORS={[
											"#F5B7B1",
											"#D7BDE2",
											"#AED6F1",
											"#A3E4D7",
											"#7DCEA0",
											"#F5CBA7",
											"#CCD1D1",
											"#F5B041",
										]}
									/>
								</Grid>
								<Grid className="PieChartKeys" item xs={4}>
									{pieChartPayroll.map((item) => {
										return (
											<div className="pieChartItemName">
												<div
													style={{
														width: 10,
														height: 10,
														background: item.color,
														borderRadius: 20,
													}}
												/>
												<h1
													style={{
														fontSize: "0.7em",
														marginLeft: 10,
														marginBottom: 0,
													}}
												>
													{item.name}
												</h1>
											</div>
										);
									})}
								</Grid>
							</Grid>
						</Grid>
					</Grid>
				</div>

				<div className="milProductionBarChart">
					<BarChart data={barChart} />
				</div>
			</Main>
		</Box>
	);
}

const mapStateToProps = ({ barns }) => ({
	barnsClassList: barns.barnsClassList,
	barnsDetails: barns.barnsDetails,
	pieChartPayroll: barns.pieChartPayroll,
	pieChartHW: barns.pieChartHundredWeight,
	barChart: barns.barChart,
	payroll: barns.payroll,
	hundredWeight: barns.hundredWeight,
});
export default connect(mapStateToProps, {})(Cart);
