// @flow
import { StyleSheet } from "aphrodite";

export default StyleSheet.create({
	payrollRow: {
		backgroundImage:
			"linear-gradient(61deg, #AED6F1 15%, #5DADE2 53%, #2874A6 99%)",
		borderRadius: 20,
		width: "100%",
		height: 50,
		paddingRight: 30,
		paddingLeft: 30,
	},
	
});
