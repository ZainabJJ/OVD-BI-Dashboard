// @flow
import React from "react";
import { css } from "aphrodite";
import { TextField, Button, Modal } from "../../components";
import styles from "./SignInStyles";
import { Images, AppStyles } from "../../theme";
import { NavLink } from "react-router-dom";
import MicrosoftLogin from "react-microsoft-login";
import { Grid } from "@mui/material/index";
import { USER_LOGIN_THEME, ROUTES } from "../../constants";
import Util from "../../services/Util";

export default function SignUpModalView(props) {
	return (
		<div className={`${css(styles.wrapper)}`}>
			<div className={`${css(styles.loginBgColor, AppStyles.container)}`}>
				<div className={`${css(styles.loginWraper)}`}>
					<div className={`row`}>
						<div className={`col-lg-12 col-md-12 col-sm-12`}>
							<div className={css(styles.loginHeadContainer)}>
								<h6 className={css(styles.loginHead)}>Log in</h6>
								<h4 className={css(styles.loginSubHead)}>
									Log into your account
								</h4>
							</div>
						</div>
					</div>

					<div className={`row`}>
						<div className={`col-lg-12 col-md-12 col-sm-12`}>
							<form className={css(styles.fomrContainer)} onSubmit={{}}>
								<div className={`row mb-2`}>
									<div className={`form-group col-md-6`}>
										<label
											className={`mb-2 ${css(styles.labelForm)}`}
										>
											Company email
										</label>
										<input
											type="email"
											className={`form-control ${css(
												styles.inputControl
											)}`}
											name="email"
											value={props.email}
											onChange={props.onChange}
											placeholder="contact@mybusiness.com"
										></input>
										<span className={`${css(AppStyles.formError)}`}>
											{props.emailError}
										</span>
									</div>
									<div className={`form-group col-md-6`}>
										<div
											className={css(styles.passwordLabelContainer)}
										>
											<label
												className={`mb-2 ${css(styles.labelForm)}`}
											>
												Password
											</label>
											<p
												className={`mb-2 ${css(
													styles.labelForm,
													styles.forgotPswd
												)}`}
												onClick={props.onForgotPasswordClick}
											>
												Forgot your password ?
											</p>
										</div>

										<input
											type="password"
											className={`form-control ${css(
												styles.inputControl
											)}`}
											name="password"
											value={props.password}
											onChange={props.onChange}
											placeholder="******"
											onKeyDown={(e) => {
												if (e.key === "Enter")
													props.onSigninClick();
											}}
										></input>
										<span className={`${css(AppStyles.formError)}`}>
											{props.passwordError}
										</span>
									</div>
								</div>
							</form>
						</div>
					</div>

					<div className={`row`}>
						<div className={`col-lg-6 col-md-6 col-sm-6`}>
							<div className={css(styles.microsoftBtnContainer)}>
								{/* <Button
                title="Login with Microsoft"
                isLoading={props.isLoading}
                ripple={false}
                className={css(styles.microsoftBtn)}
                onClick={() => {
                  
                  props.onMicrosoftLoginClick();
                }}
              /> */}

								<MicrosoftLogin
									useLocalStorageCache={true}
									clientId={"db2443ac-585a-43de-99fe-3efcff3770ea"}
									authCallback={props.onMicrosoftLoginClick}
									debug={false}
									// tenantUrl={
									// 	"https://login.microsoftonline.com/aabeecb9-b94d-4632-93ee-e4d01e89f531/"
									// }
									postLogoutRedirectUri={"/"}
									prompt="select_account"
								></MicrosoftLogin>
							</div>
						</div>
						<div className={`col-lg-6 col-md-6 col-sm-6`}>
							<div className={css(styles.loginBtnContainer)}>
								<Button
									title="Next"
									isLoading={props.isLoading}
									ripple={false}
									className={css(styles.loginBtn)}
									onClick={() => {
										props.onSigninClick();
									}}
								/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
