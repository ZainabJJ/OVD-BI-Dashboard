// @flow
import _, { isError } from "lodash";
import React from "react";
import { connect } from "react-redux";
import { withTranslate } from "react-redux-multilingual";
import { withRouter } from "react-router-dom";
import DashboardView from "./DashboardView";
import { Header, Drawer } from "../../components";
import Head from "next/head";
import { Box, Container, Grid } from "@mui/material";
class DashboardController extends React.Component {
	render() {
		return (
			<>
				<Header />
			</>
		);
	}
}

const mapStateToProps = ({ general }) => ({
	showSignIn: general.modals.showSignIn,
});

const actions = {};

export default connect(
	mapStateToProps,
	actions
)(withRouter(withTranslate(DashboardController)));
