// @flow
import { StyleSheet } from 'aphrodite';
import { Images, Colors } from '../../theme';

export default StyleSheet.create({
  wrapper: {
    width: '100%',
    height:'100hv',
   backgroundColor:'red',
    backgroundPosition: 'right -2px bottom -54px',
    backgroundRepeat: 'no-repeat',
    backgroundSize: '40% auto',
    '@media (max-width: 560px)': {
      paddingLeft: '20px',
      paddingRight: '20px'
    },
    zIndex:99
  },
  headerStyle: {
    backgroundColor: Colors.alto,
    width: '100%',
    height:60
  }
  
});