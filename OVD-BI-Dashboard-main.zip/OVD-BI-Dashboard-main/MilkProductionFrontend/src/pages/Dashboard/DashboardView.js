// @flow
import React from 'react';
import { css } from 'aphrodite';
import { TextField, Button, Modal } from '../../components';
import styles from './DashboardStyle';
import { Images, AppStyles } from '../../theme';
import { NavLink } from 'react-router-dom';
import { USER_LOGIN_THEME, ROUTES } from '../../constants';
import Util from '../../services/Util';
import Head from 'next/head';


export default function DashboardView(props) {
  return (
    <div className={`${css(styles.wrapper,)}`}>
       <Head>
        <title>
          Material Kit Pro
        </title>
        <meta
          name="viewport"
          content="initial-scale=1, width=device-width"
        />
      </Head>

    <div className={`${css(styles.headerStyle, )}`}>
      <div className={`${css(styles.loginWraper)}`}>
        <div className={`row`}>
          <div className={`col-lg-12 col-md-12 col-sm-12`}>
            <div className={css(styles.loginHeadContainer)}>
              <h6 className={css(styles.loginHead)}>Log in</h6>
              <h4 className={css(styles.loginSubHead)}>
                Log into your account
              </h4>
            </div>
          </div>
        </div>

       

       
      </div>
      </div>
          </div>

  );
}
