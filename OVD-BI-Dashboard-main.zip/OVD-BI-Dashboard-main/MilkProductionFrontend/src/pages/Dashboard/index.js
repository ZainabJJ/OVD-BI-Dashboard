import  DashboardController from './DashboardController';

export default DashboardController;
