import { useState, useEffect } from "react";
import { styled, useTheme } from "@mui/material/styles";
import FileUpload from "react-material-file-upload";
import _ from "lodash";
import { connect, useDispatch } from "react-redux";
import { withRouter } from "react-router-dom";
import { uploadFileRequest } from "../../actions/UploadAction";
import Papa from "papaparse";
import { Drawer, Header } from "../../components";
import { ClipLoader } from "react-spinners";
import Box from "@mui/material/Box";
import Util from "../../services/Util";
let csvToJson = require("convert-csv-to-json");

const drawerWidth = 240;
const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
	({ theme, open }) => ({
		flexGrow: 1,
		padding: theme.spacing(3),
		transition: theme.transitions.create("margin", {
			easing: theme.transitions.easing.sharp,
			duration: theme.transitions.duration.leavingScreen,
		}),
		marginLeft: `-${drawerWidth}px`,
		...(open && {
			transition: theme.transitions.create("margin", {
				easing: theme.transitions.easing.easeOut,
				duration: theme.transitions.duration.enteringScreen,
			}),
			marginLeft: 0,
		}),
	})
);

const DrawerHeader = styled("div")(({ theme }) => ({
	display: "flex",
	alignItems: "center",
	padding: theme.spacing(0, 1),
	// necessary for content to be below app bar
	...theme.mixins.toolbar,
	justifyContent: "flex-end",
}));

function UploadFile(props) {
	const dispatch = useDispatch();
	const [files, setFiles] = useState([]);
	const [jsonFiles, setJsonFiles] = useState("");
	const [isloading, setIsloading] = useState(false);

	useEffect(() => {
		if (!_.isEmpty(files)) {
			Papa.parse(files[0], {
				config: {
					transformHeader: true,
				},
				complete: function (results) {
					setJsonFiles(results.data);
				},
			});
		}
	}, [files]);

	useEffect(() => {
		if (!_.isEmpty(jsonFiles)) {
			const payload = {
				data: jsonFiles,
			};
			console.log({ payload });
			setIsloading(true);
			dispatch(
				uploadFileRequest(payload, (res) => {
					console.log({ res });
					if (res) {
						setFiles([]);
						Util.topAlert("File uploaded successfully");
					}
					setIsloading(false);
				})
			);
		}
	}, [jsonFiles]);

	return (
		<Box sx={{ display: "flex" }}>
			{isloading === true ? (
				<div className="LoaderDiv">
					<ClipLoader />
				</div>
			) : (
				<></>
			)}
			<Drawer title={"Upload"} />
			<Main open={true}>
				<DrawerHeader />
				<FileUpload
					accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
					title={isloading ? "uploading ..." : "Upload your file"}
					value={files}
					onChange={setFiles}
				/>
			</Main>
		</Box>
	);
}

const mapStateToProps = ({ general }) => ({});

const actions = { uploadFileRequest };

export default connect(mapStateToProps, actions)(UploadFile);
