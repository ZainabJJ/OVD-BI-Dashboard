import TermsOfUseController from "./TermsOfUseController";

export default TermsOfUseController;
