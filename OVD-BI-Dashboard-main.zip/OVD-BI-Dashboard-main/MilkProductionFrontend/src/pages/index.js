// @flow
import LandingPage from "./LandingPage";
import PageNotFound from "./PageNotFound";
import TermsOfUse from "./TermsOfUse";
import PrivacyPolicy from "./PrivacyPolicy";
import Login from './Login'
import SignUp from './SignUp'
import Dashboard from './Dashboard'
import Cart from './Cart'
import UploadFile from './UploadFile'

export { LandingPage,UploadFile,Cart, PrivacyPolicy, PageNotFound, TermsOfUse ,SignUp,Login,Dashboard};
