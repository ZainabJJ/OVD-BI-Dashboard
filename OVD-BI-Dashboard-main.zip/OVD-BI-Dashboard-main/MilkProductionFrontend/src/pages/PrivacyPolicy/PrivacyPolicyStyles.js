// @flow
import { StyleSheet } from "aphrodite";

export default StyleSheet.create({});
