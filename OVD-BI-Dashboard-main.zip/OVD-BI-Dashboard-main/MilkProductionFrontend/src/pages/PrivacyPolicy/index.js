import PrivacyPolicyController from "./PrivacyPolicyController";

export default PrivacyPolicyController;
