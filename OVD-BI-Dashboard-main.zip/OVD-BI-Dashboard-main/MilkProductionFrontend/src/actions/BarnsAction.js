// @flow

import {
	BARNS_DETAILS,
	CLASS_LIST,
	PIE_CHART,
	HUNDREDS_PAYROLL,
	BAR_CHART,
} from "./ActionTypes";

export function barnsDetailsRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: BARNS_DETAILS.REQUEST,
	};
}

export function barnsDetailsSuccess(data) {
	return {
		data,
		type: BARNS_DETAILS.SUCCESS,
	};
}

export function classListRequest(responseCallback) {
	return {
		responseCallback,
		type: CLASS_LIST.REQUEST,
	};
}

export function classListSuccess(data) {
	return {
		data,
		type: CLASS_LIST.SUCCESS,
	};
}

export function pieChartRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: PIE_CHART.REQUEST,
	};
}

export function pieChartSuccess(data) {
	return {
		data,
		type: PIE_CHART.SUCCESS,
	};
}

export function barChartRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: BAR_CHART.REQUEST,
	};
}

export function barChartSuccess(data) {
	return {
		data,
		type: BAR_CHART.SUCCESS,
	};
}

export function hundredsPayrollRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: HUNDREDS_PAYROLL.REQUEST,
	};
}

export function hundredsPayrollSuccess(data) {
	return {
		data,
		type: HUNDREDS_PAYROLL.SUCCESS,
	};
}
