// @flow

import {
	USER_UPLOAD_LOGO,
	USER_SIGNIN,
	USER_SOCIAL_SIGNIN,
	USER_SIGNUP,
	USER_FORGOT_PASSWORD,
	USER_RESET_PASSWORD,
	USER_LOGOUT,
	SET_LOGGED_OUT_RECENTLY,
	REFRESH_TOKEN,
	USER_MSAL,
} from "./ActionTypes";

export function refreshTokenRequest(responseCallback, payload) {
	return {
		responseCallback,
		payload,
		type: REFRESH_TOKEN.REQUEST,
	};
}
export function refreshTokenSuccess(data) {
	return {
		data,
		type: REFRESH_TOKEN.SUCCESS,
	};
}
export function userUploadLogoSuccess(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_UPLOAD_LOGO.SUCCESS,
	};
}
export function userUploadLogoRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_UPLOAD_LOGO.REQUEST,
	};
}

export function userSigninRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_SIGNIN.REQUEST,
	};
}

export function userSigninSuccess(data) {
	return {
		data,
		type: USER_SIGNIN.SUCCESS,
	};
}

export function userSocialSigninRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_SOCIAL_SIGNIN.REQUEST,
	};
}

export function userSocialSigninSuccess(data) {
	return {
		data,
		type: USER_SOCIAL_SIGNIN.SUCCESS,
	};
}

export function setUserMsal(data) {
	return {
		data,
		type: USER_MSAL,
	};
}

export function userSignupRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_SIGNUP.REQUEST,
	};
}

export function userSignupSuccess(data) {
	return {
		data,
		type: USER_SIGNUP.SUCCESS,
	};
}

export function userForgotPasswordRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_FORGOT_PASSWORD.REQUEST,
	};
}

export function userForgotPasswordSuccess(data) {
	return {
		data,
		type: USER_FORGOT_PASSWORD.SUCCESS,
	};
}

export function userResetPasswordRequest(payload, responseCallback) {
	return {
		payload,
		responseCallback,
		type: USER_RESET_PASSWORD.REQUEST,
	};
}

export function userResetPasswordSuccess(data) {
	return {
		data,
		type: USER_RESET_PASSWORD.SUCCESS,
	};
}

export function userLogoutRequest(responseCallback) {
	return {
		responseCallback,
		type: USER_LOGOUT.REQUEST,
	};
}

export function userLogoutSuccess() {
	return {
		type: USER_LOGOUT.SUCCESS,
		type: USER_LOGOUT.SUCCESS,
	};
}

export function setLoggedOutRecently(data) {
	return {
		data,
		type: SET_LOGGED_OUT_RECENTLY,
	};
}
