// @flow

import {
  UPLOAD_FILE
} from './ActionTypes';

export function uploadFileRequest(payload,responseCallback) {
    return {
    payload,
    responseCallback,
    type: UPLOAD_FILE.REQUEST
  };
}

export function uploadFileSuccess(data) {
  return {
    data,
    type: UPLOAD_FILE.SUCCESS
  };
}

