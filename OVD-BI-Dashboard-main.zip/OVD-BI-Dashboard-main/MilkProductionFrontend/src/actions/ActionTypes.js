// @flow
const REQUEST = "REQUEST";
const SUCCESS = "SUCCESS";
const CANCEL = "CANCEL";
const FAILURE = "FAILURE";

function createRequestTypes(base) {
  const res = {};
  [REQUEST, SUCCESS, FAILURE, CANCEL].forEach((type) => {
    res[type] = `${base}_${type}`;
  });
  return res;
}

export const NETWORK_INFO = "NETWORK_INFO";
export const USER_UPLOAD_LOGO = createRequestTypes("GET_VEHICLES");
export const SELECT_BOOKING_VEHICLE = "SELECT_BOOKING_VEHICLE";
export const CHANGE_BOOKING_TAB = "CHANGE_BOOKING_TAB";
export const GET_VEHICLES = createRequestTypes("GET_VEHICLES");
export const CHECK_FORBIDDEN = createRequestTypes("CHECK_FORBIDDEN");

export const HIDE_MODAL = createRequestTypes("HIDE_MODAL");
export const REFRESH_TOKEN = createRequestTypes("REFRESH_TOKEN");
export const REQUEST_A_DEMO = createRequestTypes("REQUEST_A_DEMO");
export const SET_LOGGED_OUT_RECENTLY = createRequestTypes("SET_LOGGED_OUT_RECENTLY");
export const SHOW_MODAL = createRequestTypes("SHOW_MODAL");
export const USER_FORGOT_PASSWORD = createRequestTypes("USER_FORGOT_PASSWORD");
export const USER_LOGOUT = createRequestTypes("USER_LOGOUT");
export const USER_RESET_PASSWORD = createRequestTypes("USER_RESET_PASSWORD");
export const USER_SIGNIN = createRequestTypes("USER_SIGNIN");
export const USER_SOCIAL_SIGNIN = createRequestTypes("USER_SOCIAL_SIGNIN");
export const USER_MSAL = createRequestTypes("USER_MSAL");
export const USER_SIGNUP = createRequestTypes("USER_SIGNUP");
export const UPLOAD_FILE = createRequestTypes("UPLOAD_FILE");

export const BARNS_DETAILS = createRequestTypes("BARNS_DETAILS");
export const HUNDREDS_PAYROLL = createRequestTypes("HUNDREDS_PAYROLL");
export const PIE_CHART = createRequestTypes("PIE_CHART");
export const BAR_CHART = createRequestTypes("BAR_CHART");
export const CLASS_LIST = createRequestTypes("CLASS_LIST");
