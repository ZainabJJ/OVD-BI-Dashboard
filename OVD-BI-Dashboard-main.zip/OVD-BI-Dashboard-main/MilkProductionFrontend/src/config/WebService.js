import _ from "lodash";
import Util from "../services/Util";
import { DEV_ENV } from "../constants";

// export const BASE_URL = "http://localhost:1337/api/v1/";
export const BASE_URL = "https://ovd-bi.herokuapp.com/api/v1/";
// const MAP_KEY = "";

export const API_TIMEOUT = 3000000;
export const ABORT_REQUEST_MESSAGE = "Network failed. Aborted request.";

// API USER ROUTES
export const API_LOG = process.env.REACT_APP_ENV === DEV_ENV;

export const ERROR_SOMETHING_WENT_WRONG = {
	message: "Something went wrong, Please try again later",
};
export const ERROR_NETWORK_NOT_AVAILABLE = {
	message: "Please connect to working internet",
};

export const ERROR_TIMEOUT = {
	message: "Request timeout, please check you internet!",
};

export const ERROR_SESSION_EXPIRED = {
	message: "Session expired, please refresh",
};

export const REQUEST_TYPE = {
	GET: "get",
	POST: "post",
	DELETE: "delete",
	PUT: "put",
};

// API USER ROUTES

export const USER_UPLOAD_LOGO = {
	route: "b/user/logo-upload",
	auth: true,
	type: REQUEST_TYPE.POST,
};

export const GET_VEHICLES = {
	route: "b/get-vehicles",
	auth: false,
	type: REQUEST_TYPE.POST,
};
export const USER_SIGNIN = {
	route: "login",
	auth: false,
	type: REQUEST_TYPE.POST,
};
export const USER_SOCIAL_SIGNIN = {
	route: "social-login",
	auth: false,
	type: REQUEST_TYPE.POST,
};

export const USER_FORGOT_PASSWORD = {
	route: "login",
	auth: false,
	type: REQUEST_TYPE.POST,
};

export const USER_LOGOUT = {
	route: "logout",
	auth: false,
	type: REQUEST_TYPE.POST,
};
export const USER_RESET_PASSWORD = {
	route: "login",
	auth: false,
	type: REQUEST_TYPE.POST,
};
export const USER_SIGNUP = {
	route: "login",
	auth: false,
	type: REQUEST_TYPE.POST,
};
export const UPLOAD_FILE = {
	route: "upload-data",
	auth: true,
	type: REQUEST_TYPE.POST,
};

/////////////barns  request

export const BARNS_DETAILS = {
	route: "login",
	auth: true,
	type: REQUEST_TYPE.POST,
};

//// classs list get ki ho gi TODO
export const CLASS_LIST = {
	route: "chart/get-class",
	auth: true,
	type: REQUEST_TYPE.POST,
};
export const PIE_CHART = {
	route: "login",
	auth: true,
	type: REQUEST_TYPE.POST,
};
export const HUNDREDS_PAYROLL = {
	route: "chart/cwt",
	auth: true,
	type: REQUEST_TYPE.POST,
};
export const BAR_CHART = {
	route: "chart/netweight",
	auth: true,
	type: REQUEST_TYPE.POST,
};

export const callRequest = function (
	url,
	data,
	parameter,
	header = {},
	ApiSauce,
	baseUrl = BASE_URL
) {
	const _url =
		parameter && !_.isEmpty(parameter)
			? `${url.route}/${parameter}`
			: url.route;

	if (url.auth) {
		header.Authorization = `Bearer ${Util.getCurrentAccessToken()}`;
	}
	if (url.type === REQUEST_TYPE.POST) {
		//data._csrf = Util.getCurrentCsrfToken();
		return ApiSauce.post(_url, data, header, baseUrl);
	} else if (url.type === REQUEST_TYPE.GET) {
		return ApiSauce.get(_url, data, header, baseUrl);
	} else if (url.type === REQUEST_TYPE.PUT) {
		// data._csrf = Util.getCurrentCsrfToken();
		return ApiSauce.put(_url, data, header, baseUrl);
	} else if (url.type === REQUEST_TYPE.DELETE) {
		return ApiSauce.delete(_url, data, header, baseUrl);
	}
	// return ApiSauce.post(url.route, data, _header);
};
