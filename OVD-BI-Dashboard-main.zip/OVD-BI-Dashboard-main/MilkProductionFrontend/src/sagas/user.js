import { take, put, call, fork } from "redux-saga/effects";
import {
	USER_UPLOAD_LOGO,
	USER_SIGNIN,
	USER_SOCIAL_SIGNIN,
	USER_SIGNUP,
	USER_FORGOT_PASSWORD,
	USER_RESET_PASSWORD,
	USER_LOGOUT,
} from "../actions/ActionTypes";
import {
	SAGA_ALERT_TIMEOUT,
	SOMETHING_WRONG,
	MESSAGE_TYPES,
	SIGNUP_SUCCESS_MSG,
} from "../constants";
import {
	userUploadLogoSuccess,
	userSigninSuccess,
	userLogoutSuccess,
	userSocialSigninSuccess,
	dmUpdateOrganizationSuccess,
	dmChangeMapServiceProviderFailed,
	dmChangeOfflineModeFailed,
} from "../actions/UserAction";

import {
	USER_UPLOAD_LOGO as USER_UPLOAD_LOGO_URL,
	USER_SIGNIN as USER_SIGNIN_URL,
	USER_SOCIAL_SIGNIN as USER_SOCIAL_SIGNIN_URL,
	USER_SIGNUP as USER_SIGNUP_URL,
	USER_FORGOT_PASSWORD as USER_FORGOT_PASSWORD_URL,
	USER_RESET_PASSWORD as USER_RESET_PASSWORD_URL,
	USER_LOGOUT as USER_LOGOUT_URL,
	callRequest,
} from "../config/WebService";
import ApiSauce from "../services/ApiSauce";
import Util from "../services/Util";

function alert(message, type = MESSAGE_TYPES.ERROR) {
	setTimeout(() => {
		Util.topAlert(message, type);
	}, SAGA_ALERT_TIMEOUT);
}

function* uploadLogo() {
	while (true) {
		const { payload, responseCallback } = yield take(
			USER_UPLOAD_LOGO.REQUEST
		);
		try {
			const response = yield call(
				callRequest,
				USER_UPLOAD_LOGO_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (responseCallback) responseCallback(response.status, null);
				// alert(response.message, MESSAGE_TYPES.SUCCESS);
				yield put(userUploadLogoSuccess(response.data));
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}
function* userLogin() {
	while (true) {
		const { payload, responseCallback } = yield take(USER_SIGNIN.REQUEST);
		try {
			const response = yield call(
				callRequest,
				USER_SIGNIN_URL,
				payload,
				"",
				{},
				ApiSauce
			);

			if (response.status) {
				console.log({ responseresponse: response });
				yield put(userSigninSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			console.log({ err });
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}
function* userSocialLogin() {
	while (true) {
		const { payload, responseCallback } = yield take(
			USER_SOCIAL_SIGNIN.REQUEST
		);
		try {
			const response = yield call(
				callRequest,
				USER_SOCIAL_SIGNIN_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				yield put(userSocialSigninSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			console.log({ err });
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* userSignup() {
	while (true) {
		const { payload, responseCallback } = yield take(USER_SIGNUP.REQUEST);
		try {
			const response = yield call(
				callRequest,
				USER_SIGNUP_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (payload.verificationCode) {
					// user has successfully verified his email by code
					// alert(SIGNUP_SUCCESS_MSG, MESSAGE_TYPES.SUCCESS);
					// yield put(userSignupSuccess(response.data));
					if (responseCallback)
						responseCallback(response.status, response.data);
				} else {
					if (responseCallback) responseCallback(response.status, null);
				}
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* userForgotPassword() {
	while (true) {
		const { payload, responseCallback } = yield take(
			USER_FORGOT_PASSWORD.REQUEST
		);
		try {
			const response = yield call(
				callRequest,
				USER_FORGOT_PASSWORD_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				// alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* userResetPassword() {
	while (true) {
		const { payload, responseCallback } = yield take(
			USER_RESET_PASSWORD.REQUEST
		);
		try {
			const response = yield call(
				callRequest,
				USER_RESET_PASSWORD_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* userLogout() {
	while (true) {
		const { responseCallback } = yield take(USER_LOGOUT.REQUEST);
		const payload = { token: Util.getCurrentRefreshToken() };

		try {
			const response = yield call(
				callRequest,
				USER_LOGOUT_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (responseCallback) responseCallback(response.status, null);
				yield put(userLogoutSuccess());
			} else {
				if (responseCallback) responseCallback(null, true);
				yield put(userLogoutSuccess());
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			yield put(userLogoutSuccess());
			// alert(err.message);
		}
	}
}

export default function* root() {
	yield fork(userLogin);
	yield fork(uploadLogo);
	yield fork(userSignup);
	yield fork(userSocialLogin);
	yield fork(userForgotPassword);
	yield fork(userResetPassword);
	yield fork(userLogout);
}
