import { take, put, call, fork } from "redux-saga/effects";
import {
	BARNS_DETAILS,
	CLASS_LIST,
	PIE_CHART,
	HUNDREDS_PAYROLL,
	BAR_CHART,
} from "../actions/ActionTypes";
import {
	SAGA_ALERT_TIMEOUT,
	SOMETHING_WRONG,
	MESSAGE_TYPES,
	SIGNUP_SUCCESS_MSG,
} from "../constants";
import {
	classListSuccess,
	barnsDetailsSuccess,
	pieChartSuccess,
	hundredsPayrollSuccess,
	barChartSuccess,
} from "../actions/BarnsAction";

import {
	BARNS_DETAILS as BARNS_DETAILS_URL,
	CLASS_LIST as CLASS_LIST_URL,
	PIE_CHART as PIE_CHART_URL,
	HUNDREDS_PAYROLL as HUNDREDS_PAYROLL_URL,
	BAR_CHART as BAR_CHART_URL,
	callRequest,
} from "../config/WebService";
import ApiSauce from "../services/ApiSauce";
import Util from "../services/Util";

function alert(message, type = MESSAGE_TYPES.ERROR) {
	setTimeout(() => {
		Util.topAlert(message, type);
	}, SAGA_ALERT_TIMEOUT);
}

function* barnsClassList() {
	while (true) {
		/////payload remove krna hn TODO
		const { responseCallback } = yield take(CLASS_LIST.REQUEST);
		try {
			const response = yield call(
				callRequest,
				CLASS_LIST_URL,
				{
					email: "dev@yopmail.com",
					password: "test123",
				},
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				if (responseCallback) responseCallback(response.status, null);
				// alert(response.message, MESSAGE_TYPES.SUCCESS);
				yield put(classListSuccess(response.data));
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}
function* barnsDetails() {
	while (true) {
		const { payload, responseCallback } = yield take(BARNS_DETAILS.REQUEST);
		try {
			const response = yield call(
				callRequest,
				BARNS_DETAILS_URL,
				payload,
				"",
				{},
				ApiSauce
			);

			if (response.status) {
				yield put(barnsDetailsSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			console.log({ err });
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* pieChart() {
	while (true) {
		const { payload, responseCallback } = yield take(PIE_CHART.REQUEST);
		try {
			const response = yield call(
				callRequest,
				PIE_CHART_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				yield put(pieChartSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* hundreadAndPayroll() {
	while (true) {
		const { payload, responseCallback } = yield take(
			HUNDREDS_PAYROLL.REQUEST
		);
		try {
			const response = yield call(
				callRequest,
				HUNDREDS_PAYROLL_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				yield put(hundredsPayrollSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				// alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

function* barChart() {
	while (true) {
		const { payload, responseCallback } = yield take(BAR_CHART.REQUEST);
		try {
			const response = yield call(
				callRequest,
				BAR_CHART_URL,
				payload,
				"",
				{},
				ApiSauce
			);
			if (response.status) {
				yield put(barChartSuccess(response.data));
				if (responseCallback) responseCallback(response.status, null);
			} else {
				if (responseCallback) responseCallback(null, true);
				alert(response.message || SOMETHING_WRONG);
			}
		} catch (err) {
			if (responseCallback) responseCallback(null, err);
			alert(err.message);
		}
	}
}

export default function* root() {
	yield fork(barnsDetails);
	yield fork(barnsClassList);
	yield fork(pieChart);
	yield fork(hundreadAndPayroll);
	yield fork(barChart);
}
