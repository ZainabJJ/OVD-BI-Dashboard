import { take, put, call, fork } from "redux-saga/effects";
import { GET_VEHICLES ,UPLOAD_FILE} from "../actions/ActionTypes";
import { SAGA_ALERT_TIMEOUT, SOMETHING_WRONG } from "../constants";
import { getVehiclesSuccess } from "../actions/GeneralActions";
import { uploadFileSuccess } from "../actions/UploadAction";

import {
  GET_VEHICLES as GET_VEHICLES_URL,
  UPLOAD_FILE as UPLOAD_FILE_URL,
  callRequest,
} from "../config/WebService";
import ApiSauce from "../services/ApiSauce";
import Util from "../services/Util";

function alert(message, type = "error") {
  setTimeout(() => {
    Util.topAlert(message, type);
  }, SAGA_ALERT_TIMEOUT);
}
function* getVehicles() {
  while (true) {
    const { responseCallback } = yield take(GET_VEHICLES.REQUEST);
    try {
      const response = yield call(
        callRequest,
        GET_VEHICLES_URL,
        {},
        "",
        {},
        ApiSauce
      );

      if (response) {
        if (responseCallback) responseCallback(true, null);
      } else {
        if (responseCallback) responseCallback(null);
        alert(SOMETHING_WRONG);
      }
    } catch (err) {
      if (responseCallback) responseCallback(null, err);
      alert(err.message);
    }
  }
}
function* uploadFile() {
  while (true) {
    const { payload, responseCallback } = yield take(UPLOAD_FILE.REQUEST);
    console.log({payload});
    try {
      const response = yield call(
        callRequest,
        UPLOAD_FILE_URL,
        payload,
        "",
        {},
        ApiSauce
      );
      console.log({response});
       if (response) {
        if (responseCallback) responseCallback(true, null);
      } else {
        if (responseCallback) responseCallback(null);
        alert(SOMETHING_WRONG);
      }
    } catch (err) {
      if (responseCallback) responseCallback(null, err);
      console.log({err});
      alert(err.message);
    }
  }
}
export default function* root() {
  yield fork(getVehicles);
  yield fork(uploadFile);

}

