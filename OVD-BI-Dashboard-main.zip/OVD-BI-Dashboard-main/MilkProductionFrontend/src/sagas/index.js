import { fork } from "redux-saga/effects";
import general from "./general";
import user from "./user";
import barns from './barns'

export default function* root() {
  yield fork(general);
  yield fork(user);
  yield fork(barns);

}
