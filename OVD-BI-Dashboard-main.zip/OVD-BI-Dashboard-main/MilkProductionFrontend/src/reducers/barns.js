// @flow
import _ from "lodash";
import { randomHexColor } from "random-hex-color-generator";
import Immutable from "seamless-immutable";
import {
	BARNS_DETAILS,
	CLASS_LIST,
	PIE_CHART,
	HUNDREDS_PAYROLL,
	BAR_CHART,
} from "../actions/ActionTypes";

const initialState = Immutable({
	barnsClassList: [],
	pieChartPayroll: [],
	pieChartHundredWeight: [],
	hundredWeight: [],
	payroll: [],
	barnsDetails: [],
	barChart: [
		{
			name: "Page G",
			uv: 3490,
			pv: 4300,
			amt: 2100,
		},
	],
});

export default (state = initialState, action) => {
	switch (action.type) {
		case BARNS_DETAILS.SUCCESS: {
			return Immutable.merge(state, {
				// barnsDetails: action.data,
			});
		}
		case CLASS_LIST.SUCCESS: {
			return Immutable.merge(state, {
				barnsClassList: action.data,
			});
		}
		case PIE_CHART.SUCCESS: {
			return Immutable.merge(state, {
				// pieChart: action.data,
			});
		}
		case HUNDREDS_PAYROLL.SUCCESS: {
			let data = action.data;
			let pieChartPayrollArray = [];
			let pieChartHWArray = [];
			let barnDetailArray = [];
			let payrollArray = [];
			let hundredWeightArray = [];
			let COLORS = [
				"#F5B7B1",
				"#D7BDE2",
				"#AED6F1",
				"#A3E4D7",
				"#7DCEA0",
				"#F5CBA7",
				"#CCD1D1",
				"#F5B041",
			];
			for (let index = 0; index < data.length; index++) {
				const element = data[index];
				if (element.name !== "Total") {
					pieChartPayrollArray.push({
						name: element.name,
						value: element.payroll,
						color: COLORS[index % COLORS.length],
					});
				}
				if (
					_.includes(["Barn 1", "Barn 4", "Barn 5", "Total"], element.name)
				) {
					let cwtCostAmount =
						element.cwtCost == 0 ? 0 : element.cwtCost.toFixed(2);
					barnDetailArray.push({
						h1: element.name,
						h2: "Cost Per CWT",
						h3: "$" + cwtCostAmount,
					});
					payrollArray.push({
						title: element.name + " Amount",
						value: element.payroll,
					});
					hundredWeightArray.push({
						title: element.name + " CWT",
						value: element.hundredWeight,
					});
					if (element.name !== "Total") {
						pieChartHWArray.push({
							name: element.name,
							value: element.hundredWeight,
							color: COLORS[index % COLORS.length],
						});
					}
				}
			}
			return Immutable.merge(state, {
				pieChartPayroll: pieChartPayrollArray,
				pieChartHundredWeight: pieChartHWArray,
				barnsDetails: barnDetailArray,
				hundredWeight: hundredWeightArray,
				payroll: payrollArray,
			});
		}
		case BAR_CHART.SUCCESS: {
			return Immutable.merge(state, {
				barChart: action.data,
			});
		}

		default:
			return state;
	}
};
