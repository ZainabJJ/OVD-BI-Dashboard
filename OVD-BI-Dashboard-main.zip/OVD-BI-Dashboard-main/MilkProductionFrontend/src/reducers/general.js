// @flow
import _ from "lodash";
import Immutable from "seamless-immutable";
import {
	SHOW_MODAL,
	HIDE_MODAL,
	USER_LOGOUT,
	REFRESH_TOKEN,
	USER_SIGNIN,
	GET_VEHICLES,
} from "../actions/ActionTypes";
import { MODAL_TYPES, TASK_FIELDS_NAME } from "../constants";

const defaultModalsState = {
	showSignupModal: false,
	showSigninModal: false,
	forgotPasswordModal: false,
	resetPasswordModal: false,
};

const initialState = Immutable({
	accessToken: "",
	refreshToken: "",
	selectedIndex: 0,
	vehicleTypes: [],
	showEta: true,

	modals: {
		showSignupModal: false,
		showSigninModal: false,
		forgotPasswordModal: false,
		resetPasswordModal: false,
	},
});

export default (state = initialState, action) => {
	switch (action.type) {
		case SHOW_MODAL: {
			const modalValues = _.cloneDeep(defaultModalsState);

			if (action.modalType === MODAL_TYPES.SIGNIN_MODAL) {
				modalValues.showSigninModal = true;
			} else if (action.modalType === MODAL_TYPES.SIGNUP_MODAL) {
				modalValues.showSignupModal = true;
			} else if (action.modalType === MODAL_TYPES.FORGOT_PASSWORD) {
				modalValues.forgotPasswordModal = true;
			} else if (action.modalType === MODAL_TYPES.RESET_PASSWORD) {
				modalValues.resetPasswordModal = true;
			}

			return Immutable.merge(state, {
				modals: modalValues,
			});
		}

		case HIDE_MODAL: {
			const modalValues = _.cloneDeep(defaultModalsState);

			return Immutable.merge(state, {
				modals: modalValues,
			});
		}
	
		case GET_VEHICLES.SUCCESS: {
			return Immutable.merge(state, {
				vehicleTypes: action.data,
			});
		}

		default:
			return state;
	}
};
