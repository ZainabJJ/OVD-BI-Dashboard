import { combineReducers } from "redux";

import general from "./general";
import user from  './user'
import barns from  './barns'

export default combineReducers({
  general,
  user,
  barns
});
