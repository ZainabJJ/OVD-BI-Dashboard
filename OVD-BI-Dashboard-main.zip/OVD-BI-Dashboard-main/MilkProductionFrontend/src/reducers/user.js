// @flow
import Immutable from "seamless-immutable";
import {
	USER_SIGNIN,
	USER_SOCIAL_SIGNIN,
	USER_LOGOUT,
	USER_MSAL,
} from "../actions/ActionTypes";

const initialState = Immutable({
	data: {},
	access_token: "",
	msal: "",
});

export default (state = initialState, action) => {
	switch (action.type) {
		case USER_SIGNIN.SUCCESS: {
			return Immutable.merge(state, {
				access_token: action.data.access_token,
				data: action.data,
			});
		}
		case USER_SOCIAL_SIGNIN.SUCCESS: {
			return Immutable.merge(state, {
				access_token: action.data.access_token,
				data: action.data,
			});
		}
		// when user logout then empty data
		case USER_LOGOUT.SUCCESS: {
			return Immutable.merge(state, initialState);
		}

		case USER_MSAL: {
			
			return Immutable.merge(state, {
				msal: action.data,
			});
		}

		default:
			return state;
	}
};
