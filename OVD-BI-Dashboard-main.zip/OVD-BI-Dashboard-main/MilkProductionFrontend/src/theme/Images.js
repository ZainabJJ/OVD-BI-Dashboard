const logo = require("../assets/images/logo.png");
const ovd_logo = require("../assets/images/logo.png");

const logo_with_text = require("../assets/images/logo_with_text.png");
const logo_green = require("../assets/images/logo-kiffgo.png");

export default {
	logo_with_text,
	logo_green,
	logo,
};
