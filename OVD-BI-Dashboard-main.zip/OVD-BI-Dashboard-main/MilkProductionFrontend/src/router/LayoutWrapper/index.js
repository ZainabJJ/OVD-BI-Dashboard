import LayoutWrapperController from "./LayoutWrapperController";

export default LayoutWrapperController;
