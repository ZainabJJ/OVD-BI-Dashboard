// @flow
import React from "react";

export default function LayoutWrapperView(props) {
  return <>{props.children}</>;
}
