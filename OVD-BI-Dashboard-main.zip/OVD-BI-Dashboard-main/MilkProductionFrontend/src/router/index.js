import React from "react";
import {
	Route,
	BrowserRouter as Router,
	Switch,
	Redirect,
} from "react-router-dom";
import { connect } from "react-redux";
import { ROUTES } from "../constants";
import {
	LandingPage,
	PageNotFound,
	TermsOfUse,
	PrivacyPolicy,
	Login,
	Dashboard,
	Cart, // ye cart nai chart hai
	UploadFile,
	SignUp,
} from "../pages";
import LayoutWrapper from "./LayoutWrapper";
import { isLoggedIn, setUserLoggedOutRecently } from "../helpers/userHelper";

const NoAuthRoute = ({ ...props }) => {
	return (
		<LayoutWrapper>
			<Route {...props} />
		</LayoutWrapper>
	);
};
const AuthRoute = (props) => {
	if (!isLoggedIn()) {
		if (props.user.isLoggedOutRecently) {
			setUserLoggedOutRecently(false);
			return <Redirect to={`${ROUTES.LOGIN}`} />;
		}
		return (
			<Redirect to={`${ROUTES.LOGIN}?redirect=${props.location.pathname}`} />
		);
	}

	return (
		<LayoutWrapper>
			<Route {...props} />
		</LayoutWrapper>
	);
};

class Routers extends React.PureComponent {
	render() {
		const { user } = this.props;
		const repeatedProps = {
			user,
			exact: true,
			forAdminOnly: false,
		};
		return (
			<Router>
				<div>
					<Switch>
						<NoAuthRoute
							path={ROUTES.LOGIN}
							component={Login}
							{...repeatedProps}
						/>
						<AuthRoute
							path={ROUTES.DASHBOARD}
							component={UploadFile}
							{...repeatedProps}
						/>

						<AuthRoute
							path={ROUTES.CHARTS}
							component={Cart}
							{...repeatedProps}
						/>

						<NoAuthRoute
							path={ROUTES.TERMS_OF_USE}
							component={TermsOfUse}
							{...repeatedProps}
						/>
						<NoAuthRoute
							path={ROUTES.SIGN_UP}
							component={SignUp}
							{...repeatedProps}
						/>

						<NoAuthRoute
							path={ROUTES.PRIVACY_POLICY}
							component={PrivacyPolicy}
							{...repeatedProps}
						/>

						{/* Keep this in last always */}
						<NoAuthRoute
							path={Route.PAGE_NOT_FOUND}
							component={PageNotFound}
						/>
					</Switch>
				</div>
			</Router>
		);
	}
}

const mapStateToProps = ({ user }) => ({
	user,
});

const actions = {};

export default connect(mapStateToProps, actions)(Routers);
